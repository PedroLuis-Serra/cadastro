package com.example.cadastroveiculos3A.repository;

import com.example.cadastroveiculos3A.model.Veiculo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VeiculoRepository extends JpaRepository<Veiculo, Long> {
}
