package com.example.cadastroveiculos3A;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cadastroveiculos3AApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cadastroveiculos3AApplication.class, args);
	}

}
