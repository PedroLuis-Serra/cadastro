package com.example.cadastroveiculos3A;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cadastroveiculos3AApplicationTests {

	@Test
	void contextLoads() {
	}

}
